package com.example.hw_15;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private Integer firstVar;
    private Integer secondVar;
    private boolean isOperationClick;
    private String operation;
    private Integer result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.text_view);
    }

    public void setNumber(String number) {
        if (textView.getText().toString().equals("0")) {
            textView.setText(number);
        } else if (isOperationClick) {
            textView.setText(number);
        } else {
            textView.append(number);
        }
        isOperationClick = false;
    }

    public void onNumberClick(View view) {
        switch (view.getId()) {
            case R.id.btn_one:
                setNumber("1");
                break;
            case R.id.btn_two:
                setNumber("2");
                break;
            case R.id.btn_three:
                setNumber("3");
                break;
            case R.id.btn_four:
                setNumber("4");
                break;
            case R.id.btn_five:
                setNumber("5");
                break;
            case R.id.btn_six:
                setNumber("6");
                break;
            case R.id.btn_seven:
                setNumber("7");
                break;
            case R.id.btn_eight:
                setNumber("8");
                break;
            case R.id.btn_nine:
                setNumber("9");
                break;
            case R.id.btn_zero:
                setNumber("0");
                break;
            case R.id.btn_clear:
                textView.setText("0");
                isOperationClick = false;
                firstVar = 0;
                secondVar = 0;
                break;

        }
        isOperationClick = false;
    }

    @SuppressLint("SetTextI18n")
    public void onOperationClick(View view) {

        switch (view.getId()) {
            case R.id.btn_plus:
                firstVar = Integer.parseInt(textView.getText().toString());
                isOperationClick = true;
                operation = "+";
                break;
            case R.id.btn_minus:
                firstVar = Integer.parseInt(textView.getText().toString());
                isOperationClick = true;
                operation = "-";
                break;
            case R.id.btn_multiply:
                firstVar = Integer.parseInt(textView.getText().toString());
                isOperationClick = true;
                operation = "X";
                break;
            case R.id.btn_divide:
                firstVar = Integer.parseInt(textView.getText().toString());
                isOperationClick = true;
                operation = "/";
                break;

                /*case R.id.btn_percent:
                    firstVar = Double.parseDouble(textView.getText().toString());
                    double resultt = Double.valueOf(0);
                    isOperationClick = true;
                    operation = "/";
                    switch (operation) {
                        case "/":
                            resultt = firstVar / 100;
                            break;

                        case R.id.btn_value:
                            firstVar = Double.parseDouble(textView.getText().toString());
                            double resultS = Double.valueOf(0);
                            isOperationClick = true;
                            operation = "+/-";
                            resultS = firstVar *= -1;
                            break;
                    }
                    R.id.btn_equal (new DecimalFormat("##.#######").format(resul));*/

            case R.id.btn_equal:
                secondVar = Integer.parseInt(textView.getText().toString());
                textView.setText(Integer.toString(result));
                switch (operation) {
                    case "+":
                        result = firstVar + secondVar;
                        break;

                    case "-":
                        result = firstVar - secondVar;
                        break;

                    case "X":
                        result = firstVar * secondVar;
                        break;

                    case "/":
                        result = firstVar / secondVar;
                        break;
                }
                isOperationClick = true;
                break;
        }
    }
}